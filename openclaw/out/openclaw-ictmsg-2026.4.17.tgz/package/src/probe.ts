import { getIctmsgClient } from "./gateway.js";
import type { IctmsgResolvedAccount } from "./types.js";

export async function probeIctmsg(
  account: IctmsgResolvedAccount,
): Promise<{ healthy: boolean; message: string }> {
  const client = getIctmsgClient(account.id);

  if (!client) {
    return {
      healthy: false,
      message: `Client not initialized for account: ${account.id}`,
    };
  }

  const isConnected = client.isConnected();

  return {
    healthy: isConnected,
    message: `${isConnected ? "Connected to" : "Disconnected from"} ICTMSG (appId: ${account.appId})`,
  };
}
