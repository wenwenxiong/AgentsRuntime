import type { ChannelConfigAdapter } from "openclaw/plugin-sdk/channel-runtime";
import type { OpenClawConfig } from "openclaw/plugin-sdk";
import { DEFAULT_ACCOUNT_ID } from "openclaw/plugin-sdk/account-id";
import type { IctmsgConfig, IctmsgResolvedAccount } from "./types.js";

export function createIctmsgAccountsAdapter(): ChannelConfigAdapter<IctmsgResolvedAccount> {
  return {
    listAccountIds: (cfg: OpenClawConfig): string[] => {
      const ictmsgCfg = cfg.channels?.ictmsg as IctmsgConfig | undefined;
      const accounts = ictmsgCfg?.accounts ?? {};
      const accountIds = Object.keys(accounts);
      return accountIds.length > 0 ? accountIds : [DEFAULT_ACCOUNT_ID];
    },

    resolveAccount: (cfg: OpenClawConfig, accountId?: string | null): IctmsgResolvedAccount => {
      const resolvedAccountId = accountId ?? DEFAULT_ACCOUNT_ID;
      const ictmsgCfg = cfg.channels?.ictmsg as IctmsgConfig | undefined;
      const accountConfig = ictmsgCfg?.accounts?.[resolvedAccountId];

      const baseEnabled = ictmsgCfg?.enabled !== false;
      const accountEnabled = accountConfig?.enabled !== false;
      const enabled = baseEnabled && accountEnabled;

      const url = accountConfig?.url ?? ictmsgCfg?.url;
      const appId = accountConfig?.appId ?? ictmsgCfg?.appId;
      const appSecret = accountConfig?.appSecret ?? ictmsgCfg?.appSecret;

      const configured = Boolean(url && appId && appSecret);

      return {
        id: resolvedAccountId,
        enabled,
        configured,
        url: url ?? "",
        appId: appId ?? "",
        appSecret: appSecret ?? "",
        heartbeatInterval: accountConfig?.heartbeatInterval ?? ictmsgCfg?.heartbeatInterval ?? 30,
      };
    },

    defaultAccountId: () => DEFAULT_ACCOUNT_ID,

    isConfigured: (account: IctmsgResolvedAccount): boolean => {
      return !!(account.url && account.appId && account.appSecret);
    },

    setAccountEnabled: ({
      cfg,
      accountId,
      enabled,
    }: {
      cfg: OpenClawConfig;
      accountId: string;
      enabled: boolean;
    }): OpenClawConfig => {
      const ictmsgCfg = cfg.channels?.ictmsg as IctmsgConfig | undefined;
      return {
        ...cfg,
        channels: {
          ...cfg.channels,
          ictmsg: {
            ...ictmsgCfg,
            accounts: {
              ...ictmsgCfg?.accounts,
              [accountId]: {
                ...ictmsgCfg?.accounts?.[accountId],
                enabled,
              },
            },
          },
        },
      };
    },

    deleteAccount: ({
      cfg,
      accountId,
    }: {
      cfg: OpenClawConfig;
      accountId: string;
    }): OpenClawConfig => {
      const ictmsgCfg = cfg.channels?.ictmsg as IctmsgConfig | undefined;
      const accounts = { ...ictmsgCfg?.accounts };
      delete accounts[accountId];

      return {
        ...cfg,
        channels: {
          ...cfg.channels,
          ictmsg: {
            ...ictmsgCfg,
            accounts: Object.keys(accounts).length > 0 ? accounts : undefined,
          },
        },
      };
    },
  };
}
