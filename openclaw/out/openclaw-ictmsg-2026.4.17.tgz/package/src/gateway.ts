import type { ChannelGatewayAdapter } from "openclaw/plugin-sdk/channel-runtime";
import type { ChannelGatewayContext, ReplyPayload, OpenClawConfig } from "openclaw/plugin-sdk";
import {
  normalizeAgentId,
  buildAgentSessionKey,
  buildAgentMainSessionKey,
  deriveLastRoutePolicy,
  resolveAgentRoute,
} from "openclaw/plugin-sdk/routing";
import {
  finalizeInboundContext,
  dispatchReplyWithBufferedBlockDispatcher,
} from "openclaw/plugin-sdk/reply-dispatch-runtime";
import { IctmsgClient } from "./client.js";
import { fetchLinkerAddr } from "./registry.js";
import type { IctmsgResolvedAccount, IctmsgMessage } from "./types.js";

const DEFAULT_AGENT_ID = "main";

function listAgentIds(cfg: OpenClawConfig): string[] {
  const agents = cfg.agents?.list;
  if (!Array.isArray(agents) || agents.length === 0) {
    return [DEFAULT_AGENT_ID];
  }
  const seen = new Set<string>();
  const ids: string[] = [];
  for (const entry of agents) {
    const id = normalizeAgentId(entry?.id);
    if (!id || seen.has(id)) continue;
    seen.add(id);
    ids.push(id);
  }
  return ids.length > 0 ? ids : [DEFAULT_AGENT_ID];
}

const clients = new Map<string, IctmsgClient>();

export function registerIctmsgClient(accountId: string, client: IctmsgClient): void {
  clients.set(accountId, client);
}

export function unregisterIctmsgClient(accountId: string): void {
  clients.delete(accountId);
}

export function getIctmsgClient(accountId: string): IctmsgClient | undefined {
  return clients.get(accountId);
}

function createMessageHandler(
  client: IctmsgClient,
  ctx: ChannelGatewayContext<IctmsgResolvedAccount>,
): (msg: IctmsgMessage) => Promise<void> {
  const { accountId, cfg, log, setStatus } = ctx;

  return async (msg: IctmsgMessage): Promise<void> => {
    if (msg.type === 0) {
      setStatus?.({
        accountId,
        lastEventAt: Date.now(),
      });
      return;
    }

    if (msg.type === 998) {
      log?.info?.(`[ictmsg] Connection established`);
      setStatus?.({
        accountId,
        connected: true,
        lastConnectedAt: Date.now(),
        lastEventAt: Date.now(),
      });
      return;
    }

    if (msg.type === 1) {
      if (!msg.data || !msg.sessionId) {
        log?.warn?.(`[ictmsg] Invalid message: missing data or sessionId`);
        return;
      }

      setStatus?.({
        accountId,
        lastEventAt: Date.now(),
        lastInboundAt: Date.now(),
      });

      const msgPreview = msg.data.length > 50 ? `${msg.data.substring(0, 50)}...` : msg.data;
      log?.debug?.(`[ictmsg] Received from ${msg.sessionId}: "${msgPreview}"`);

      try {
        let route = resolveAgentRoute({
          cfg,
          channel: "ictmsg",
          accountId,
          peer: { kind: "direct", id: msg.sessionId },
        });

        if (msg.agentId) {
          const normalizedAgentId = normalizeAgentId(msg.agentId);
          const agentIds = listAgentIds(cfg);

          if (!agentIds.includes(normalizedAgentId)) {
            log?.error?.(`[ictmsg] Invalid agentId: ${msg.agentId}`);
            const availableAgents = agentIds.join(", ");
            if (client.send({
              type: 1,
              data: `错误：Agent "${msg.agentId}" 不存在。可用的 agents: ${availableAgents}`,
              requestId: msg.requestId,
              sessionId: msg.sessionId,
              timestamp: Date.now(),
            })) {
              client.send({
                type: 1,
                data: "[DONE]",
                requestId: msg.requestId,
                sessionId: msg.sessionId,
                timestamp: Date.now(),
              });
            }
            return;
          }
          const sessionKey = buildAgentSessionKey({
            agentId: normalizedAgentId,
            channel: "ictmsg",
            accountId,
            peer: { kind: "direct", id: msg.sessionId },
            dmScope: cfg.session?.dmScope,
            identityLinks: cfg.session?.identityLinks,
          }).toLowerCase();

          const mainSessionKey = buildAgentMainSessionKey({
            agentId: normalizedAgentId,
          }).toLowerCase();

          route = {
            ...route,
            agentId: normalizedAgentId,
            sessionKey,
            mainSessionKey,
            matchedBy: "default",
            lastRoutePolicy: deriveLastRoutePolicy({ sessionKey, mainSessionKey }),
          };
          log?.debug?.(`[ictmsg] Using agentId from message: ${normalizedAgentId}`);
        }

        const rawCtx = {
          Provider: "ictmsg",
          Surface: "ictmsg",
          AccountId: accountId,
          SessionKey: route.sessionKey,
          MessageSid: msg.requestId ?? `${Date.now()}`,
          Body: msg.data,
          BodyStripped: msg.data,
          RawBody: msg.data,
          CommandBody: msg.data,
          SenderId: msg.sessionId,
          SenderName: msg.sessionId,
          ChatType: "direct" as const,
          CommandAuthorized: true,
        };

        const finalizedCtx = finalizeInboundContext(rawCtx);

        let doneSent = false;
        let blockCount = 0;
        let totalChars = 0;

        await dispatchReplyWithBufferedBlockDispatcher({
          ctx: finalizedCtx,
          cfg,
          dispatcherOptions: {
            deliver: async (payload: ReplyPayload, info: { kind: string }) => {
              if (payload.text) {
                blockCount++;
                totalChars += payload.text.length;
                const ts = new Date().toISOString();
                log?.debug?.(
                  `[ictmsg] [${ts}] Block ${blockCount} (${info.kind}): ${payload.text.length} chars`,
                );
                log?.debug?.(`[ictmsg] Content:\n${payload.text}`);
                client.send({
                  type: 1,
                  data: payload.text,
                  requestId: msg.requestId,
                  sessionId: msg.sessionId,
                  timestamp: Date.now(),
                });
              }

              if (info.kind === "final" && !doneSent) {
                doneSent = true;
                const ts = new Date().toISOString();
                log?.debug?.(`[ictmsg] [${ts}] Sending [DONE] marker (final)`);
                client.send({
                  type: 1,
                  data: "[DONE]",
                  requestId: msg.requestId,
                  sessionId: msg.sessionId,
                  timestamp: Date.now(),
                });
              }
            },
            onError: (err: unknown) => {
              log?.error?.(`[ictmsg] Dispatch error: ${err}`);
            },
          },
        });

        if (!doneSent) {
          const ts = new Date().toISOString();
          log?.debug?.(`[ictmsg] [${ts}] Sending [DONE] marker (dispatch complete)`);
          client.send({
            type: 1,
            data: "[DONE]",
            requestId: msg.requestId,
            sessionId: msg.sessionId,
            timestamp: Date.now(),
          });
        }

        log?.info?.(
          `[ictmsg] Sent ${blockCount} blocks (${totalChars} chars) to ${msg.sessionId}`,
        );
      } catch (err) {
        log?.error?.(`[ictmsg] Dispatch failed: ${err}`);
        if (client.send({
          type: 1,
          data: "抱歉，处理消息时出现错误。",
          requestId: msg.requestId,
          sessionId: msg.sessionId,
          timestamp: Date.now(),
        })) {
          client.send({
            type: 1,
            data: "[DONE]",
            requestId: msg.requestId,
            sessionId: msg.sessionId,
            timestamp: Date.now(),
          });
        }
      }
    }
  };
}

export function createIctmsgGatewayAdapter(): ChannelGatewayAdapter<IctmsgResolvedAccount> {
  return {
    startAccount: async (ctx: ChannelGatewayContext<IctmsgResolvedAccount>): Promise<void> => {
      const { accountId, log, abortSignal, setStatus } = ctx;
      const account = ctx.account;

      log?.info?.(`[ictmsg] Starting account ${accountId}`);

      let registryResult;
      try {
        log?.info?.(`[ictmsg] Registering with url: ${account.url}`);
        registryResult = await fetchLinkerAddr({
          url: account.url,
          appId: account.appId,
          appSecret: account.appSecret,
        });
        log?.debug?.(
          `[ictmsg] Registry result details: url=${registryResult.url}, username=${registryResult.username}, mac=${registryResult.mac}`,
        );
      } catch (err) {
        const errorMsg = err instanceof Error ? err.message : String(err);
        log?.error?.(`[ictmsg] Registration failed: ${errorMsg}`);
        setStatus?.({
          accountId,
          running: false,
          connected: false,
          lastError: `Registration failed: ${errorMsg}`,
          lastDisconnect: {
            at: Date.now(),
            error: `Registration failed: ${errorMsg}`,
          },
        });
        throw err;
      }

      // 占位 handler，会在 setMessageHandler 中被覆盖
      const client = new IctmsgClient(
        account,
        () => {},
        { log: log?.info, error: log?.error, debug: log?.debug, warn: log?.warn },
        (code: number, reason: string) => {
          log?.warn?.(`[ictmsg] Gateway connection closed: code=${code}, reason=${reason}`);
          setStatus?.({
            accountId,
            connected: false,
            lastDisconnect: {
              at: Date.now(),
              status: code,
              error: reason,
            },
          });
          unregisterIctmsgClient(accountId);
        },
      );

      client.setMessageHandler(createMessageHandler(client, ctx));

      try {
        await client.connect({
          url: registryResult.url,
          username: registryResult.username,
          password: registryResult.password,
        });
        registerIctmsgClient(accountId, client);
        const now = Date.now();
        setStatus?.({
          accountId,
          running: true,
          connected: true,
          lastStartAt: now,
          lastConnectedAt: now,
        });
        log?.info?.(`[ictmsg] Account ${accountId} started`);

        await new Promise<void>((resolve, reject) => {
          let checkInterval: ReturnType<typeof setInterval> | null = null;

          const cleanup = () => {
            if (checkInterval) {
              clearInterval(checkInterval);
              checkInterval = null;
            }
            abortSignal.removeEventListener("abort", onAbort);
          };

          const onAbort = () => {
            cleanup();
            log?.info?.(`[ictmsg] Stopping...`);
            resolve();
          };

          abortSignal.addEventListener("abort", onAbort);

          // 健康检查: 每秒检测连接状态，断开时立即退出
          checkInterval = setInterval(() => {
            if (!client.isConnected()) {
              cleanup();
              reject(new Error("WebSocket disconnected"));
            }
          }, 1000);
        });
      } catch (err) {
        unregisterIctmsgClient(accountId);
        const errorMsg = err instanceof Error ? err.message : String(err);
        setStatus?.({
          accountId,
          running: false,
          connected: false,
          lastError: errorMsg,
          lastDisconnect: {
            at: Date.now(),
            error: errorMsg,
          },
        });
        throw err;
      }
    },

    stopAccount: async (ctx: ChannelGatewayContext<IctmsgResolvedAccount>): Promise<void> => {
      const { accountId, log, setStatus } = ctx;

      log?.info?.(`[ictmsg] Stopping account ${accountId}`);

      const client = getIctmsgClient(accountId);
      if (client) {
        client.disconnect();
        unregisterIctmsgClient(accountId);
      }

      setStatus?.({
        accountId,
        running: false,
        connected: false,
        lastStopAt: Date.now(),
      });
      log?.info?.(`[ictmsg] Account ${accountId} stopped`);
    },
  };
}
