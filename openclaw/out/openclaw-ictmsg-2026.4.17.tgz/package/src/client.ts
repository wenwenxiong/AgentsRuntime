import WebSocket from "ws";
import type { IctmsgResolvedAccount, IctmsgMessage } from "./types.js";

type Logger = {
  log?: (message: string, ...args: unknown[]) => void;
  error?: (message: string, ...args: unknown[]) => void;
  debug?: (message: string, ...args: unknown[]) => void;
  warn?: (message: string, ...args: unknown[]) => void;
};

type DisconnectHandler = (code: number, reason: string) => void;

export class IctmsgClient {
  private ws: WebSocket | null = null;
  private heartbeatTimer: ReturnType<typeof setInterval> | null = null;
  private account: IctmsgResolvedAccount;
  private messageHandler: (msg: IctmsgMessage) => Promise<void> | void;
  private isStopped = false;
  private logger: Logger;
  private disconnectHandler?: DisconnectHandler;
  private lastPongAt: number = 0;
  private timeoutCheckCount: number = 0;
  private instanceId: string; // 实例唯一标识

  // 获取日志前缀
  private logPrefix(): string {
    return `[ictmsg][${this.instanceId}]`;
  }

  constructor(
    account: IctmsgResolvedAccount,
    messageHandler: (msg: IctmsgMessage) => Promise<void> | void,
    logger?: Logger,
    disconnectHandler?: DisconnectHandler,
  ) {
    this.account = account;
    this.messageHandler = messageHandler;
    this.logger = logger ?? { log: console.log, error: console.error };
    this.disconnectHandler = disconnectHandler;
    // 生成6位随机实例ID
    this.instanceId = Math.random().toString(36).substring(2, 8).toUpperCase();
  }

  setMessageHandler(handler: (msg: IctmsgMessage) => Promise<void> | void): void {
    this.messageHandler = handler;
  }

  async connect(params: { url: string; username: string; password: string }): Promise<void> {
    if (this.isStopped) {
      return Promise.reject(new Error("Client is stopped"));
    }

    const auth = Buffer.from(`${params.username}:${params.password}`).toString("base64");

    return new Promise((resolve, reject) => {
      try {
        this.ws = new WebSocket(params.url, {
          headers: {
            Authorization: `Basic ${auth}`,
          },
        });
        let isResolved = false;

        this.ws.on("open", () => {
          this.logger.log?.(`${this.logPrefix()} Connected to ${params.url}`);
          this.startHeartbeat();

          isResolved = true;
          resolve();
        });

        this.ws.on("message", (data: WebSocket.Data) => {
          try {
            const msg: IctmsgMessage = JSON.parse(data.toString());
            if (msg.type === 0) {
              this.lastPongAt = Date.now();
              this.timeoutCheckCount = 0;
              this.logger.debug?.(`${this.logPrefix()} Pong received`);
            } else {
              this.logger.debug?.(`${this.logPrefix()} Raw message: ${data.toString()}`);
            }
            Promise.resolve(this.messageHandler(msg)).catch((err) => {
              this.logger.error?.(`${this.logPrefix()} Message handler error:`, err);
            });
          } catch (err) {
            this.logger.error?.(`${this.logPrefix()} Failed to parse message:`, err);
          }
        });

        this.ws.on("close", (code: number, reason: Buffer) => {
          if (this.isStopped) return;
          const reasonStr = reason.toString();
          this.logger.log?.(
            `${this.logPrefix()} Client WebSocket closed: code=${code}, reason=${reasonStr}`,
          );
          this.stopHeartbeat();
          this.disconnectHandler?.(code, reasonStr);
        });

        this.ws.on("error", (err: Error) => {
          this.logger.error?.(`${this.logPrefix()} WebSocket error:`, err);
          if (!isResolved) {
            reject(err);
          }
        });
      } catch (err) {
        reject(err);
      }
    });
  }

  send(message: IctmsgMessage): boolean {
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(message));
      return true;
    }
    this.logger.warn?.(`${this.logPrefix()} Send failed: WebSocket not connected`);
    return false;
  }

  private startHeartbeat(): void {
    this.stopHeartbeat();
    this.lastPongAt = Date.now();
    this.timeoutCheckCount = 0;

    // 连接后立即发送第一个心跳，避免服务端空闲超时
    if (this.send({
      type: 0,
      data: "ping",
      timestamp: Date.now(),
    })) {
      this.logger.debug?.(`${this.logPrefix()} First ping sent`);
    }

    const heartbeatTimeout = this.account.heartbeatInterval + 10;

    // 超时策略: 连续2次超时才断开，容忍偶发网络抖动
    this.heartbeatTimer = setInterval(() => {
      const now = Date.now();
      const elapsed = (now - this.lastPongAt) / 1000;

      if (elapsed > heartbeatTimeout) {
        this.timeoutCheckCount++;
        this.logger.warn?.(
          `${this.logPrefix()} Pong timeout: ${elapsed.toFixed(1)}s > ${heartbeatTimeout}s (count: ${this.timeoutCheckCount})`,
        );

        if (this.timeoutCheckCount > 1) {
          this.isStopped = true;
          this.stopHeartbeat();
          if (this.ws) {
            const reason = `Pong timeout after ${elapsed.toFixed(1)}s`;
            this.logger.log?.(`${this.logPrefix()} Terminating connection: reason=${reason}`);
            this.ws.terminate();
            this.disconnectHandler?.(1000, reason);
          }
          return;
        }
      }

      if (this.send({
        type: 0,
        data: "ping",
        timestamp: now,
      })) {
        this.logger.debug?.(
          `${this.logPrefix()} Ping sent (interval: ${this.account.heartbeatInterval}s, timeout: ${heartbeatTimeout}s)`,
        );
      }
    }, this.account.heartbeatInterval * 1000);
  }

  private stopHeartbeat(): void {
    if (this.heartbeatTimer) {
      clearInterval(this.heartbeatTimer);
      this.heartbeatTimer = null;
    }
  }

  disconnect(): void {
    this.isStopped = true;

    this.stopHeartbeat();

    if (this.ws) {
      this.ws.close(1000, "Client disconnecting");
      this.ws = null;
    }

    this.logger.log?.(`${this.logPrefix()} Disconnected`);
  }

  isConnected(): boolean {
    return this.ws?.readyState === WebSocket.OPEN;
  }
}
