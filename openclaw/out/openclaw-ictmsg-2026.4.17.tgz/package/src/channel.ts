import type { ChannelPlugin, OpenClawConfig, ChannelSetupInput } from "openclaw/plugin-sdk";
import { DEFAULT_ACCOUNT_ID } from "openclaw/plugin-sdk/account-id";
import { createIctmsgAccountsAdapter } from "./accounts.js";
import { IctmsgChannelConfigSchema } from "./config-schema.js";
import { createIctmsgGatewayAdapter } from "./gateway.js";
import { createIctmsgOutboundAdapter } from "./outbound.js";
import { probeIctmsg } from "./probe.js";
import { resolveIctmsgOutboundSessionRoute } from "./session-route.js";
import type { IctmsgResolvedAccount, IctmsgConfig } from "./types.js";

export const ictmsgPlugin: ChannelPlugin<IctmsgResolvedAccount> = {
  id: "ictmsg",
  meta: {
    id: "ictmsg",
    label: "ICTMSG",
    selectionLabel: "ICTMSG",
    docsPath: "/channels/ictmsg",
    blurb: "ICTMSG WebSocket Channel",
  },
  capabilities: {
    chatTypes: ["direct"],
  },
  configSchema: IctmsgChannelConfigSchema,
  config: createIctmsgAccountsAdapter(),
  outbound: createIctmsgOutboundAdapter(),
  gateway: createIctmsgGatewayAdapter(),
  messaging: {
    resolveOutboundSessionRoute: (params) => resolveIctmsgOutboundSessionRoute(params),
    targetResolver: {
      looksLikeId: (id: string) => id.trim().length > 0,
      hint: "<sessionId>",
    },
  },
  status: {
    probeAccount: async ({
      account,
    }: {
      account: IctmsgResolvedAccount;
    }): Promise<{ healthy: boolean; message: string }> => probeIctmsg(account),
  },
  setup: {
    resolveAccountId: () => DEFAULT_ACCOUNT_ID,
    applyAccountConfig: ({
      cfg,
      accountId,
      input,
    }: {
      cfg: OpenClawConfig;
      accountId: string;
      input: ChannelSetupInput;
    }) => {
      const ictmsgCfg = cfg.channels?.ictmsg as IctmsgConfig | undefined;
      return {
        ...cfg,
        channels: {
          ...cfg.channels,
          ictmsg: {
            ...ictmsgCfg,
            enabled: true,
            accounts: {
              ...ictmsgCfg?.accounts,
              [accountId]: {
                ...ictmsgCfg?.accounts?.[accountId],
                enabled: true,
              },
            },
          },
        },
      };
    },
  },
};
