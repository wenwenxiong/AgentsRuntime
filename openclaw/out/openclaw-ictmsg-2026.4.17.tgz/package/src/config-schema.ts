import { z } from "zod";
import { buildChannelConfigSchema } from "openclaw/plugin-sdk/channel-config-schema";

export const IctmsgAccountConfigSchema = z.object({
  enabled: z.boolean().optional(),
  url: z.string(),
  appId: z.string(),
  appSecret: z.string(),
  heartbeatInterval: z.number().min(30).optional(),
});

export const IctmsgConfigSchema = z.object({
  enabled: z.boolean().optional(),
  url: z.string().optional(),
  appId: z.string().optional(),
  appSecret: z.string().optional(),
  heartbeatInterval: z.number().min(30).optional(),
  accounts: z.record(z.string(), IctmsgAccountConfigSchema).optional(),
});

export const IctmsgChannelConfigSchema = buildChannelConfigSchema(IctmsgConfigSchema, {});

