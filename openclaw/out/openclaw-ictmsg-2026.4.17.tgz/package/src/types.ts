/**
 * ICTMSG WebSocket 消息类型
 * type: 0=心跳, 1=业务消息(双向), 2=主动出站/通知, 998=连接成功
 */
export interface IctmsgMessage {
  type: 0 | 1 | 2 | 998;
  data: string;
  requestId?: string;
  sessionId?: string;
  agentId?: string;
  timestamp?: number;
}

/**
 * ICTMSG 账号配置
 */
export interface IctmsgAccountConfig {
  enabled?: boolean;
  url: string;
  appId: string;
  appSecret: string;
  heartbeatInterval?: number;
}

/**
 * ICTMSG 通道配置
 */
export interface IctmsgConfig {
  enabled?: boolean;
  url?: string;
  appId?: string;
  appSecret?: string;
  heartbeatInterval?: number;
  accounts?: Record<string, IctmsgAccountConfig>;
}

/**
 * 解析后的 ICTMSG 账号配置
 */
export interface IctmsgResolvedAccount {
  id: string;
  enabled: boolean;
  configured: boolean;
  url: string;
  appId: string;
  appSecret: string;
  heartbeatInterval: number;
}

/**
 * 注册 API 响应结果
 */
export interface RegistryResult {
  url: string;
  username: string;
  password: string;
  mac: string;
}
