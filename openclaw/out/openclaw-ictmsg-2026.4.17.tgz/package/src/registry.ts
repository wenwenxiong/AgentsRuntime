import crypto from "node:crypto";
import type { RegistryResult } from "./types.js";

const RESPONSE_TIMEOUT_MS = 30_000;

function sortJsonObject(obj: unknown): unknown {
  if (typeof obj !== "object" || obj === null) {
    return obj;
  }

  if (Array.isArray(obj)) {
    return obj.map(sortJsonObject);
  }

  const sorted: Record<string, unknown> = {};
  const keys = Object.keys(obj).sort();
  for (const key of keys) {
    const value = (obj as Record<string, unknown>)[key];
    if (value !== null && value !== undefined && value !== "") {
      sorted[key] = sortJsonObject(value);
    }
  }
  return sorted;
}

function sortJsonString(jsonStr: string): string {
  const parsed = JSON.parse(jsonStr);
  return JSON.stringify(sortJsonObject(parsed));
}

export function sign(params: {
  appId: string;
  appSecret: string;
  timestamp: number;
  body: string;
}): string {
  const queryString = "";
  const bodyString = sortJsonString(params.body);
  const signData = params.appId + params.timestamp.toString() + queryString + bodyString;

  const hmac = crypto.createHmac("sha256", params.appSecret);
  hmac.update(signData);
  return hmac.digest("base64").replace(/\s/g, "");
}

export async function fetchLinkerAddr(params: {
  url: string;
  appId: string;
  appSecret: string;
}): Promise<RegistryResult> {
  const timestamp = Date.now();
  const body = JSON.stringify({ protocol: 1 });
  const signature = sign({ ...params, timestamp, body });

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), RESPONSE_TIMEOUT_MS);

  try {
    const url = params.url;

    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        appId: params.appId,
        signature,
        timestamp: timestamp.toString(),
      },
      body,
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    if (!response.ok) {
      throw new Error(`Registry HTTP error: ${response.status} ${response.statusText}`);
    }

    const result = (await response.json()) as {
      resCode: number;
      data: {
        mac: string;
        protocol: number;
        url?: string;
        username: string;
        password: string;
      };
      resDesc?: string;
    };

    if (result.resCode !== 0) {
      throw new Error(`Registry failed: ${result.resDesc ?? `resCode=${result.resCode}`}`);
    }

    if (!result.data.url) {
      throw new Error("Registry returned no WebSocket URL");
    }

    return {
      url: result.data.url,
      username: result.data.username,
      password: result.data.password,
      mac: result.data.mac,
    };
  } catch (err) {
    clearTimeout(timeoutId);
    if (err instanceof Error && err.name === "AbortError") {
      throw new Error(`Registry request timed out after ${RESPONSE_TIMEOUT_MS}ms`);
    }
    throw err;
  }
}
