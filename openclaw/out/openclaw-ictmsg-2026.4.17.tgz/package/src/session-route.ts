import {
  buildOutboundBaseSessionKey,
  type RoutePeer,
} from "openclaw/plugin-sdk/routing";
import type { OpenClawConfig } from "openclaw/plugin-sdk";

export function resolveIctmsgOutboundSessionRoute(params: {
  cfg: OpenClawConfig;
  agentId: string;
  accountId?: string | null;
  target: string;
}) {
  const sessionId = params.target.trim();
  if (!sessionId) {
    return null;
  }

  const peer: RoutePeer = {
    kind: "direct",
    id: sessionId,
  };

  const baseSessionKey = buildOutboundBaseSessionKey({
    cfg: params.cfg,
    agentId: params.agentId,
    channel: "ictmsg",
    accountId: params.accountId,
    peer,
  });

  return {
    sessionKey: baseSessionKey,
    baseSessionKey,
    peer,
    chatType: "direct" as const,
    from: `ictmsg:${sessionId}`,
    to: sessionId,
  };
}
