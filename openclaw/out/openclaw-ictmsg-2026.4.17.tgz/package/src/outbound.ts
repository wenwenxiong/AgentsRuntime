import type { ChannelOutboundContext, ChannelOutboundAdapter } from "openclaw/plugin-sdk/channel-runtime";
import { DEFAULT_ACCOUNT_ID } from "openclaw/plugin-sdk/account-id";
import { getIctmsgClient } from "./gateway.js";
import type { IctmsgMessage } from "./types.js";
import { createSubsystemLogger } from "openclaw/plugin-sdk/runtime-env";

const log = createSubsystemLogger("ictmsg");

type OutboundDeliveryResult = {
  channel: "ictmsg";
  ok: boolean;
  messageId: string;
  error?: string;
};

export function createIctmsgOutboundAdapter(): ChannelOutboundAdapter {
  return {
    deliveryMode: "direct",

    sendText: async (ctx: ChannelOutboundContext): Promise<OutboundDeliveryResult> => {
      const { text, replyToId, accountId } = ctx;

      const resolvedAccountId = accountId ?? DEFAULT_ACCOUNT_ID;

      const client = getIctmsgClient(resolvedAccountId);
      if (!client) {
        throw new Error(`ICTMSG client not found for account: ${resolvedAccountId}`);
      }

      const sessionId = ctx.to;
      const messageId = `${Date.now()}`;
      
      log.debug?.(`[ictmsg] Outbound to sessionId: ${sessionId}, text: ${text}`);

      const ictmsgResponse: IctmsgMessage = {
        type: 2,
        data: text,
        sessionId,
        timestamp: Date.now(),
      };

      const success = client.send(ictmsgResponse);
      if (!success) {
        throw new Error(`Failed to send message: WebSocket not connected`);
      }

      return {
        channel: "ictmsg",
        ok: true,
        messageId,
      };
    },
  };
}
