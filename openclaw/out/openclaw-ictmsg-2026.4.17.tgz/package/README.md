# ICTMSG Channel Plugin for OpenClaw

将 ICTMSG WebSocket 平台接入 OpenClaw Gateway。

## 安装

```bash
pnpm add @openclaw/ictmsg
```

## 开发

```bash
pnpm type-check              # 类型检查
pnpm pack                    # 打包插件
```

## Docker 部署

```bash
make all                     # 完整流程: pack + build + run + install
make pack                    # 打包插件
make build                   # 构建 Docker 镜像
make run                     # 启动容器
make install                 # 安装插件到容器
make logs                    # 查看日志
make shell                   # 进入容器终端
make restart                 # 完整重启
make clean                   # 清理
make list                    # 列出已安装插件
```

## 认证流程

```
1. 注册阶段
   ├── 调用注册 API (url + appId + appSecret)
   ├── 获取 WebSocket URL
   └── 获取 Basic Auth 凭证 (username/password)

2. 连接阶段
   ├── 使用注册结果中的 URL 建立 WebSocket
   └── 使用 Basic Auth Header 认证
```

## 配置

在 `~/.openclaw/openclaw.json` 中添加：

```json
{
  "channels": {
    "ictmsg": {
      "enabled": true,
      "heartbeatInterval": 30,
      "accounts": {
        "default": {
          "enabled": true,
          "url": "https://your-server/ictclaw/linker/v1/openapi/upstream",
          "appId": "your-app-id",
          "appSecret": "your-app-secret",
          "heartbeatInterval": 30
        }
      }
    }
  }
}
```

### 配置项说明

| 配置项                | 类型    | 必填         | 默认值 | 说明              |
| --------------------- | ------- | ------------ | ------ | ----------------- |
| `enabled`           | boolean | 否           | true   | 是否启用频道      |
| `url`               | string  | **是** | -      | 注册 API 完整地址 |
| `appId`             | string  | **是** | -      | 应用 ID           |
| `appSecret`         | string  | **是** | -      | 应用密钥          |
| `heartbeatInterval` | number  | 否           | 30     | 心跳间隔（秒）    |

### 多账号支持

支持配置多个账号，每个账号使用不同的注册凭证：

```json
{
  "channels": {
    "ictmsg": {
      "enabled": true,
      "accounts": {
        "account1": {
          "url": "https://server1/ictclaw/linker/v1/openapi/upstream",
          "appId": "app-id-1",
          "appSecret": "secret-1"
        },
        "account2": {
          "url": "https://server2/ictclaw/linker/v1/openapi/upstream",
          "appId": "app-id-2",
          "appSecret": "secret-2"
        }
      }
    }
  }
}
```

## 消息协议

### 消息类型

| type | 说明                |
| ---- | ------------------- |
| 0    | 心跳                |
| 1    | 业务消息 (入站)     |
| 2    | 业务消息 (主动推送) |
| 998  | 连接成功            |

### 接收消息（ICTMSG → OpenClaw）

```json
{
  "type": 1,
  "data": "用户消息内容",
  "requestId": "单次请求ID",
  "sessionId": "用户会话ID",
  "agentId": "sales-bot",
  "timestamp": 1234567890
}
```

### 发送消息（OpenClaw → ICTMSG）

```json
{
  "type": 1,
  "data": "AI回复内容",
  "requestId": "原requestId",
  "sessionId": "原sessionId",
  "timestamp": 1234567890
}
```

### 流式消息

OpenClaw 支持流式回复，消息会分块发送，最后发送 `[DONE]` 标记：

```json
{"type": 1, "data": "第一块内容", "sessionId": "xxx", ...}
{"type": 1, "data": "第二块内容", "sessionId": "xxx", ...}
{"type": 1, "data": "[DONE]", "sessionId": "xxx", ...}
```

### Agent 路由

消息可通过 `agentId` 字段指定目标 Agent：

```json
{
  "type": 1,
  "data": "你好",
  "sessionId": "user_123",
  "agentId": "sales-bot"
}
```

**路由行为：**

- 有 `agentId`：路由到指定 Agent（需在 `agents.list` 中配置）
- `agentId` 无效：返回错误消息，列出可用 Agent
- 无 `agentId`：使用 OpenClaw 默认路由（通常为 "main"）

### ID 映射

| ICTMSG        | OpenClaw      | 说明          |
| ------------- | ------------- | ------------- |
| `sessionId` | `threadId`  | 会话/线程标识 |
| `requestId` | `messageId` | 消息标识      |

## 项目结构

```
openclaw-ictmsg/
├── index.ts              # 插件入口
├── package.json          # 包配置
├── tsconfig.json         # TypeScript 配置
├── openclaw.plugin.json  # 插件清单
├── Makefile              # Docker 命令
├── src/
│   ├── channel.ts        # ChannelPlugin 定义
│   ├── config-schema.ts  # Zod 配置校验
│   ├── gateway.ts        # WebSocket 网关适配器
│   ├── outbound.ts       # 消息发送适配器
│   ├── accounts.ts       # 账号配置适配器
│   ├── session-route.ts  # 会话路由解析
│   ├── client.ts         # WebSocket 客户端
│   ├── probe.ts          # 健康检查
│   ├── registry.ts       # 注册 API
│   └── types.ts          # 类型定义
└── dockerfiles/
    └── Dockerfile.openclaw
```

## 开发工作流

1. **类型检查**: `pnpm type-check`
2. **打包插件**: `pnpm pack`
3. **部署**: `make all`
4. **查看日志**: `make logs`
5. **测试**: 通过 WebSocket 客户端发送消息

## 调试

启用详细日志：

```json
{
  "logging": {
    "level": "debug",
    "consoleLevel": "debug"
  }
}
```