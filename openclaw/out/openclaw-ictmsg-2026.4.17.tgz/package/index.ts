import type { OpenClawPluginApi } from "openclaw/plugin-sdk";
import { ictmsgPlugin } from "./src/channel.js";

export default function register(api: OpenClawPluginApi) {
  api.registerChannel({ plugin: ictmsgPlugin });
}
